import os
from abc import ABC
from ecloudsdkcore.auth.util import auth_constants as ac

from ecloudsdkcore.auth.credential import Credential
from ecloudsdkcore.exception.exceptions import CredentialException


class AbstractCredentialProvider(ABC):

    def get_credential(self):
        pass


class BasicCredentialProvider(AbstractCredentialProvider):

    def __init__(self, credential):
        self.credential = credential

    def get_credential(self):
        return self.credential

    @staticmethod
    def create(credential):
        return BasicCredentialProvider(credential)


class EnvCredentialProvider(AbstractCredentialProvider):
    def __init__(self):
        pass

    @staticmethod
    def create():
        return EnvCredentialProvider()

    def get_credential(self):
        access_key = os.getenv(ac.ENV_AK_KEY)
        secret_key = os.getenv(ac.ENV_SK_KEY)
        private_key = os.getenv(ac.ENV_MOP_PRIVATE_KEY)
        public_key = os.getenv(ac.ENV_MOP_PUBLIC_KEY)
        if access_key and secret_key:
            return Credential(access_key=access_key, secret_key=secret_key, private_key=private_key,
                              public_key=public_key)
        else:
            raise CredentialException("EnvCredentialProvider: accessKey or secretKey cannot be empty")


class ProfileCredentialProvider(AbstractCredentialProvider):
    def __init__(self, path=None):
        super().__init__()
        self.file_path = path

    def get_credential(self):
        return Credential(access_key=None, secret_key=None, private_key=None, public_key=None)
