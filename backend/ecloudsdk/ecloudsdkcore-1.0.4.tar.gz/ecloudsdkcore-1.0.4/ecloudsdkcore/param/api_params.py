# coding: utf-8


class ApiParams(object):

    def __init__(
            self,
            action=None,
            protocol=None,
            uri=None,
            gateway_uri=None,
            request=None,
            method=None,
            auth_type=None,
            content_type=None,
    ):
        self.action = action
        self.protocol = protocol
        self.uri = uri
        self.gateway_uri = gateway_uri
        self.request = request
        self.method = method
        self.auth_type = auth_type
        self.content_type = content_type
