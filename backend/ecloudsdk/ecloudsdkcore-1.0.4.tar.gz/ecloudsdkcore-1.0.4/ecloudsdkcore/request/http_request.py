# coding: utf-8
import six

from ecloudsdkcore.config.config import AuthType
from ecloudsdkcore.position.request_position import Body, Header, Query, Path
from ecloudsdkcore.util.convert_util import sanitize_for_serialization, covert_dictvalue_to_str
from ecloudsdkcore.util.string_util import percent_encode, has_text, is_empty
from ecloudsdkcore.util.common_util import default_value, is_unset, is_set, DEFAULT_ENDPOINT
from ecloudsdkcore.auth.util import auth_constants as ac


class HttpRequest(object):

    def __init__(
            self,
            action=None,
            url=None,
            path=None,
            protocol=None,
            method="POST",
            product=None,
            version=None,
            sdk_version=None,
            source=None,
            security_token=None,
            body=None,
            content_type=None,
            endpoint=None,
            head_params=None,
            path_params=None,
            query_params=None,
    ):
        self.action = action
        self.url = url
        self.path = path
        self.protocol = protocol
        self.method = method
        self.product = product
        self.version = version
        self.sdk_version = sdk_version
        self.source = source
        self.security_token = security_token
        self.body = body
        self.content_type = content_type
        self.endpoint = endpoint
        self.head_params = head_params
        self.path_params = path_params
        self.query_params = query_params
        self.query_string = ""

    def reset(self):
        self.body = None
        self.head_params = None
        self.path_params = None
        self.query_params = None
        self.query_string = ""
        self.security_token = ""

    def convert_request(self, request):
        if request:
            for _, value in request.__dict__.items():
                if isinstance(value, Body):
                    self.body = value
                elif isinstance(value, Header):
                    self.build_header_params(sanitize_for_serialization(value))
                elif isinstance(value, Path):
                    self.build_path_params(sanitize_for_serialization(value))
                elif isinstance(value, Query):
                    self.build_query_params(sanitize_for_serialization(value))

    def build_api_params(self, params, config, runtime_config):
        if is_unset(params):
            return
        if has_text(params.content_type):
            self.content_type = params.content_type
        if has_text(params.method):
            self.method = params.method
        if has_text(params.protocol):
            self.protocol = params.protocol
        if has_text(params.action):
            self.action = params.action

        ignore_gateway = default_value(runtime_config.ignore_gateway, config.ignore_gateway)
        if ignore_gateway:
            self.path = params.uri
        else:
            self.path = params.gateway_uri

        if is_set(self.path_params) and len(self.path_params) > 0:
            self.build_path_params_string()

        if is_set(config.global_query_params):
            self.build_query_params(config.global_query_params)

        if is_set(config.global_header_params):
            self.build_header_params(config.global_header_params)

        if is_set(runtime_config.runtime_header_params):
            self.build_header_params(runtime_config.runtime_header_params)

        if has_text(config.pool_id):
            self.add_headers({"Pool-Id": config.pool_id})

        if has_text(config.security_token):
            self.security_token = config.security_token

        if has_text(config.source):
            self.source = config.source

        self.add_default_headers()

        auth_type = default_value(runtime_config.auth_type, config.auth_type)
        if auth_type != AuthType.AK:
            self.build_query_params_string()

        central_transport_enabled = default_value(runtime_config.central_transport_enabled,
                                                  config.central_transport_enabled)
        if not central_transport_enabled and has_text(self.endpoint):
            self.url = self.endpoint
        else:
            self.url = DEFAULT_ENDPOINT

        http_proxy = default_value(runtime_config.http_proxy, config.http_proxy)
        if has_text(http_proxy):
            self.url = http_proxy

        https_proxy = default_value(runtime_config.https_proxy, config.https_proxy)
        if has_text(https_proxy):
            self.url = https_proxy

    def build_final_url(self):
        url = self.url
        if is_empty(url):
            return
        protocol = self.protocol
        if has_text(protocol) and not url.startswith("http"):
            url = protocol + "://" + url
        path = self.path
        if has_text(path):
            url = url + path
        query_string = self.query_string
        if has_text(query_string):
            url = url + "?" + query_string
        self.url = url

    def build_path_params_string(self):
        new_path = self.path
        for key, value in six.iteritems(self.path_params):
            new_path = new_path.replace("{%s}" % key, value)
        if not new_path.startswith("/"):
            new_path = "/" + new_path
        if new_path.endswith("/"):
            new_path = new_path[0:-1]
        self.path = new_path

    def build_path_params(self, global_path_params):
        if is_unset(self.path_params):
            self.path_params = {}
        self.path_params.update(covert_dictvalue_to_str(global_path_params))

    def build_query_params(self, global_query_params):
        if is_unset(self.query_params):
            self.query_params = {}
        self.query_params.update(covert_dictvalue_to_str(global_query_params))

    def build_header_params(self, global_header_params):
        if is_unset(self.head_params):
            self.head_params = {}
        self.head_params.update(covert_dictvalue_to_str(global_header_params))

    def build_query_params_string(self):
        query_params = self.query_params
        if is_unset(query_params) or len(query_params) == 0:
            return
        query_string = ""
        pos = 0
        for key, value in six.iteritems(query_params):
            query_string += percent_encode(key) + "=" + percent_encode(value)
            if pos < len(query_params) - 1:
                query_string += "&"
        self.query_string = query_string

    def add_default_headers(self):
        if self.product.endswith("inner") and is_unset(self.source):
            raise ValueError("The attribute named source in SDK config must not be null")
        if is_unset(self.head_params):
            self.head_params = {}
        open_api_header = "action:{0};product:{1};version:{2};sdkversion:{3};language:Python".format(
            self.action, self.product, self.version, self.sdk_version)
        if has_text(self.source):
            open_api_header += ";source:{0}".format(self.source)
        if has_text(self.security_token):
            self.head_params["x-openapi-security-token"] = self.security_token
        self.head_params["x-openapi-sdk"] = open_api_header
        self.head_params["User-Agent"] = "OpenAPI/2.0/Python"

    def add_headers(self, headers=None):
        if is_unset(self.head_params):
            self.head_params = {}
        self.head_params.update(headers)

    def convert_query_params_from_path(self):
        if self.path.find(ac.QUERY_START_SYMBOL) != -1:
            if is_unset(self.query_params):
                self.query_params = {}
            path_array = self.path.split(ac.QUERY_START_SYMBOL)
            param_array = path_array[1].split(ac.PARAMETER_SEPARATOR)
            for param in param_array:
                if is_set(param):
                    query_param_array = param.split(ac.QUERY_EQUAL_SYMBOL)
                    self.query_params[query_param_array[0]] = query_param_array[1]
            self.path = path_array[0]
