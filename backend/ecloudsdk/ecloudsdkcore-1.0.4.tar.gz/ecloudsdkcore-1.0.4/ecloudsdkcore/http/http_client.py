# coding: utf-8
import json
import logging
import re
import ssl
from urllib.parse import urlencode

import certifi
import requests
import six
import urllib3

from ecloudsdkcore.auth.credential import CredentialType, EncryptionType
from ecloudsdkcore.auth.credential_impl import CredentialFactory
from ecloudsdkcore.exception.exceptions import ServerResponseException, ServerRequestException, SslHandShakeException, \
    ConnectTimeoutException
from ecloudsdkcore.response.HttpResponse import HttpResponse
from ecloudsdkcore.util.common_util import default_value, is_unset, is_set
from ecloudsdkcore.util.convert_util import sanitize_for_serialization, save_to_file, deserialize
from ecloudsdkcore.util.http_util import select_filename_by_header
from ecloudsdkcore.util.string_util import has_text, is_empty

logger = logging.getLogger(__name__)
requests.packages.urllib3.disable_warnings()


class HttpClient(object):

    def __init__(self, config, model_package, num_pools=8, maxsize=4, **kwargs):
        self.model_package = model_package
        self.read_timeout = config.read_timeout
        self.connect_timeout = config.connect_timeout
        self.ignore_ssl = config.ignore_ssl
        self.ca_certs = config.cert_file
        self.cert_file = config.client_cert_file
        self.key_file = config.client_key_file
        self.http_client_kw = kwargs
        self.config = config
        cert_reqs = ssl.CERT_REQUIRED
        if self.ignore_ssl:
            cert_reqs = ssl.CERT_NONE
        # ca_certs
        ca_certs = certifi.where()
        if has_text(self.ca_certs):
            ca_certs = self.ca_certs

        cert_file = None
        if has_text(self.cert_file):
            cert_file = self.cert_file
        key_file = None
        if has_text(self.key_file):
            key_file = self.key_file

        addition_pool_args = kwargs.copy()
        proxy_url = self.get_proxy()
        if is_set(proxy_url):
            self.pool_manager = urllib3.ProxyManager(
                num_pools=num_pools,
                maxsize=maxsize,
                cert_reqs=cert_reqs,
                ca_certs=ca_certs,
                cert_file=cert_file,
                key_file=key_file,
                timeout=self.acquire_timeout(),
                proxy_url=proxy_url,
                **addition_pool_args
            )
        else:
            self.pool_manager = urllib3.PoolManager(
                num_pools=num_pools,
                maxsize=maxsize,
                cert_reqs=cert_reqs,
                ca_certs=ca_certs,
                cert_file=cert_file,
                key_file=key_file,
                timeout=self.acquire_timeout(),
                **addition_pool_args
            )

    def execute(self, http_request, response_type, runtime_config):
        # body
        body = http_request.body
        if body:
            body = sanitize_for_serialization(body)
        timeout = self.acquire_timeout(runtime_config)
        backup = self.pool_manager.connection_pool_kw.copy()
        self.update_pool_kwargs(runtime_config)
        try:
            # perform request and return response
            resp = self.do_request(
                method=http_request.method,
                url=http_request.url,
                headers=http_request.head_params,
                post_params=None,
                body=body,
                preload_content=True,
                request_timeout=timeout,
                runtime_config=runtime_config
            )
        finally:
            self.pool_manager.connection_pool_kw = backup

        # resolve response data
        return_data = None
        if response_type:
            return_data = self.handle_response(resp, response_type, runtime_config)
        return return_data

    def do_request(self, method, url, query_params=None, headers=None,
                   body=None, post_params=None, preload_content=True,
                   request_timeout=None, runtime_config=None):
        method = method.upper()
        if method not in ['GET', 'HEAD', 'DELETE', 'POST', 'PUT',
                          'PATCH', 'OPTIONS']:
            raise ServerRequestException("unsupported request method: " + method)

        if post_params and body:
            raise ServerRequestException("body parameter cannot be used with post_params parameter.")

        post_params = post_params or {}
        headers = headers or {}

        timeout = None
        if request_timeout:
            if isinstance(request_timeout, (int,) if six.PY3 else (int, long)):  # noqa: E501,F821
                timeout = urllib3.Timeout(total=request_timeout)
            elif (isinstance(request_timeout, tuple) and
                  len(request_timeout) == 2):
                timeout = urllib3.Timeout(
                    connect=request_timeout[0], read=request_timeout[1])
            elif (isinstance(request_timeout, urllib3.Timeout) and
                  request_timeout is not None):
                timeout = request_timeout
        provider = default_value(runtime_config.provider, self.config.provider)
        if is_set(provider):
            credential = provider.get_credential()
            if is_set(credential):
                if credential.credential_type == CredentialType.MOP and credential.encryption_type == EncryptionType.MOP_RSA:
                    headers['Content-Type'] = 'text/plain'
                    if body is not None:
                        request_body = json.dumps(body)
                        body = CredentialFactory.get_credential_manager(credential.credential_type).encrypt(
                            request_body, credential.public_key)
        if 'Content-Type' not in headers:
            headers['Content-Type'] = 'application/json'
        headers['Content-Type'] = headers['Content-Type'].lower().strip()
        try:
            # For `POST`, `PUT`, `PATCH`, `OPTIONS`, `DELETE`
            if method in ['POST', 'PUT', 'PATCH', 'OPTIONS', 'DELETE']:
                if query_params:
                    url += '?' + urlencode(query_params)
                if re.search('json', headers['Content-Type'], re.IGNORECASE):
                    request_body = '{}'
                    if body is not None:
                        request_body = json.dumps(body)
                    resp = self.pool_manager.request(
                        method, url,
                        body=request_body,
                        preload_content=preload_content,
                        timeout=timeout,
                        headers=headers,
                        retries=False)
                elif headers['Content-Type'] == 'application/x-www-form-urlencoded':  # noqa: E501
                    resp = self.pool_manager.request(
                        method, url,
                        fields=post_params,
                        encode_multipart=False,
                        preload_content=preload_content,
                        timeout=timeout,
                        headers=headers,
                        retries=False)
                elif headers['Content-Type'] == 'multipart/form-data':
                    # must del headers['Content-Type'], or the correct
                    # Content-Type which generated by urllib3 will be
                    # overwritten.
                    del headers['Content-Type']
                    resp = self.pool_manager.request(
                        method, url,
                        fields=post_params,
                        encode_multipart=True,
                        preload_content=preload_content,
                        timeout=timeout,
                        headers=headers,
                        retries=False)
                # Pass a `string` parameter directly in the body to support
                # other content types than Json when `body` argument is
                # provided in serialized form
                elif isinstance(body, str):
                    request_body = body
                    resp = self.pool_manager.request(
                        method, url,
                        body=request_body,
                        preload_content=preload_content,
                        timeout=timeout,
                        headers=headers,
                        retries=False)
                else:
                    # Cannot generate the request from given parameters
                    msg = """Cannot prepare a request message for provided
                             arguments. Please check that your arguments match
                             declared content type."""
                    raise ServerRequestException(error_message=msg)
            # For `GET`, `HEAD`
            else:
                resp = self.pool_manager.request(method, url,
                                                 fields=query_params,
                                                 preload_content=preload_content,
                                                 timeout=timeout,
                                                 headers=headers,
                                                 retries=False)
        except urllib3.exceptions.ConnectTimeoutError as e:
            raise ConnectTimeoutException("connection timeout", reason=e)
        except urllib3.exceptions.SSLError as e:
            raise SslHandShakeException("ssl error", reason=e)
        except urllib3.exceptions.ReadTimeoutError as e:
            raise SslHandShakeException("read time out error", reason=e)
        except Exception as e:
            raise ServerRequestException("request error", reason=e)

        if preload_content:
            resp = HttpResponse(resp.status, resp.headers, resp.data)

            # In the python 3, the response.data is bytes.
            # we need to decode it to string.
            if six.PY3:
                resp.data = resp.data.decode('utf-8')

            # log response body
            logger.debug("response body: %s", resp.data)
        return resp

    def get(self, url, headers=None, query_params=None, _preload_content=True,
            _request_timeout=None):
        return self.do_request("GET", url,
                               headers=headers,
                               preload_content=_preload_content,
                               request_timeout=_request_timeout,
                               query_params=query_params)

    def head(self, url, headers=None, query_params=None, _preload_content=True,
             _request_timeout=None):
        return self.do_request("HEAD", url,
                               headers=headers,
                               preload_content=_preload_content,
                               request_timeout=_request_timeout,
                               query_params=query_params)

    def options(self, url, headers=None, query_params=None, post_params=None,
                body=None, _preload_content=True, _request_timeout=None):
        return self.do_request("OPTIONS", url,
                               headers=headers,
                               query_params=query_params,
                               post_params=post_params,
                               preload_content=_preload_content,
                               request_timeout=_request_timeout,
                               body=body)

    def delete(self, url, headers=None, query_params=None, body=None,
               _preload_content=True, _request_timeout=None):
        return self.do_request("DELETE", url,
                               headers=headers,
                               query_params=query_params,
                               preload_content=_preload_content,
                               request_timeout=_request_timeout,
                               body=body)

    def post(self, url, headers=None, query_params=None, post_params=None,
             body=None, _preload_content=True, _request_timeout=None):
        return self.do_request("POST", url,
                               headers=headers,
                               query_params=query_params,
                               post_params=post_params,
                               preload_content=_preload_content,
                               request_timeout=_request_timeout,
                               body=body)

    def put(self, url, headers=None, query_params=None, post_params=None,
            body=None, _preload_content=True, _request_timeout=None):
        return self.do_request("PUT", url,
                               headers=headers,
                               query_params=query_params,
                               post_params=post_params,
                               preload_content=_preload_content,
                               request_timeout=_request_timeout,
                               body=body)

    def patch(self, url, headers=None, query_params=None, post_params=None,
              body=None, _preload_content=True, _request_timeout=None):
        return self.do_request("PATCH", url,
                               headers=headers,
                               query_params=query_params,
                               post_params=post_params,
                               preload_content=_preload_content,
                               request_timeout=_request_timeout,
                               body=body)

    def handle_response(self, response, response_type, runtime_config):
        """Deserializes response into an object.

        :param response: HttpResponse object to be deserialized.
        :param response_type: class literal for
            deserialized object, or string of class name.
        :return: deserialized object.
        """
        if response.code < 200 or response.code >= 300:
            raise ServerResponseException(error_message="http status code is not successful",
                                          code=response.code, body=response.data)
        if is_unset(response.data):
            return None
        # handle file downloading
        # save response body into a file and return the file path
        if response_type == "file":
            file_name = select_filename_by_header(response.headers)
            if has_text(self.http_client_kw.get("save_to_file")) and is_empty(file_name):
                file_name = self.http_client_kw.get("save_to_file")
            return save_to_file(response.data, file_name, self.http_client_kw.get('save_to'))

        # fetch data from response object
        try:
            provider = default_value(runtime_config.provider, self.config.provider)
            response_body = response.data
            if is_set(provider):
                credential = provider.get_credential()
                if is_set(credential):
                    if credential.credential_type == CredentialType.MOP and credential.encryption_type == EncryptionType.MOP_RSA:
                        response_body = CredentialFactory.get_credential_manager(credential.credential_type).decrypt(
                            response.data.encode(), credential.private_key)
            data = json.loads(response_body)
            if is_unset(data):
                raise ServerResponseException(error_message="can not load data using json#loads method, "
                                                            "make sure the format of response data is json format.",
                                              code=response.code, body=response.data)
        except ValueError:
            logger.warning("value error, when using json.loads(response.data), try to using response.data directly")
            raise ServerResponseException(error_message=response.data,
                                          code=response.code)
        except Exception as e:
            raise ServerResponseException(error_message="can not load data using json#loads method, "
                                                        "make sure the format of response data is json format.",
                                          code=response.code, body=response.data)
        try:
            return deserialize(data, response_type, self.model_package)
        except Exception as e:
            raise ServerResponseException(error_message="can not deserialize response data",
                                          code=response.code, body=response.data, reason=e)

    def update_pool_kwargs(self, runtime_config):
        ignore_ssl = default_value(runtime_config.ignore_ssl, self.ignore_ssl)
        ca_certs = default_value(runtime_config.cert_file, self.ca_certs)
        cert_file = default_value(runtime_config.client_cert_file, self.cert_file)
        key_file = default_value(runtime_config.client_key_file, self.key_file)

        params = {}
        cert_reqs = ssl.CERT_REQUIRED
        if ignore_ssl:
            cert_reqs = ssl.CERT_NONE
        params["cert_reqs"] = cert_reqs
        # ca_certs
        if is_empty(ca_certs):
            ca_certs = certifi.where()
        params["ca_certs"] = ca_certs
        if has_text(cert_file):
            params["cert_file"] = cert_file
        if has_text(key_file):
            params["key_file"] = key_file
        self.pool_manager.connection_pool_kw.update(params)

    def acquire_timeout(self, runtime_config=None):
        if is_unset(runtime_config):
            return urllib3.Timeout(connect=self.connect_timeout, read=self.read_timeout)
        connect_timeout = default_value(runtime_config.connect_timeout, self.connect_timeout)
        read_timeout = default_value(runtime_config.read_timeout, self.read_timeout)
        return urllib3.Timeout(connect=connect_timeout, read=read_timeout)

    def get_proxy(self):
        if self.config.client_proxy_host is None:
            return None
        if six.PY2:
            from urllib import quote_plus
        else:
            from urllib.parse import quote_plus
        return "%s://%s%s%s" % (
            self.config.client_proxy_protocol,
            "%s:%s@" % (self.config.client_proxy_username, quote_plus(self.config.client_proxy_password)) if is_set(
                self.config.client_proxy_username) else "",
            self.config.client_proxy_host,
            ":%s" % self.config.client_proxy_port if is_set(self.config.client_proxy_port) else ""
        )

    def destroy(self):
        pass
