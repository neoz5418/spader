# coding: utf-8
import datetime
import hashlib
import hmac
import uuid
from urllib.parse import unquote_plus

from ecloudsdkcore.exception.exceptions import SignatureException
from ecloudsdkcore.util.string_util import percent_encode

ACCESS_KEY = "AccessKey"
TIMESTAMP = "Timestamp"
TIMESTAMP_FORMAT = "%Y-%m-%dT%H:%M:%SZ"
SIGNATURE = "Signature"
SECRET_KEY_PREFIX = "BC_SIGNATURE&"
SIGNATURE_METHOD = "SignatureMethod"
SIGNATURE_METHOD_VALUE = "HmacSHA1"
SIGNATURE_VERSION = "SignatureVersion"
SIGNATURE_VERSION_VALUE = "V2.0"
SIGNATURE_NONCE = "SignatureNonce"
ENCODING_NAME = "UTF-8"
LINE_SEPARATOR = "\n"
PARAMETER_SEPARATOR = "&"
QUERY_START_SYMBOL = "?"
QUERY_STRING_PATTERN = "{0}={1}"


def sign(http_request, access_key, secret_key):
    if http_request is None:
        raise ValueError("http request argument can not be None.")
    query_params = http_request.query_params or {}
    params = dict(query_params)
    params[ACCESS_KEY] = access_key
    params[SIGNATURE_METHOD] = SIGNATURE_METHOD_VALUE
    params[SIGNATURE_VERSION] = SIGNATURE_VERSION_VALUE
    params[TIMESTAMP] = get_date(TIMESTAMP_FORMAT)
    params[SIGNATURE_NONCE] = nonce()
    sorted_key = sorted(list(params.keys()))
    canonical_query_string = ""
    pos = 0
    for key in sorted_key:
        value = params.get(key)
        canonical_query_string += QUERY_STRING_PATTERN.format(percent_encode(key), percent_encode(value))
        if pos < len(sorted_key) - 1:
            canonical_query_string += PARAMETER_SEPARATOR
        pos += 1
    hash_string = sha256_encode_hex_string(canonical_query_string)
    path = http_request.path or ""
    servlet_path = unquote_plus(path)
    if http_request.method is None:
        raise SignatureException("the method of http request can bot be None")
    method = http_request.method
    string_to_sign = method.upper() + LINE_SEPARATOR + percent_encode(servlet_path) + LINE_SEPARATOR + hash_string
    signature = hmac_sha1_hex_string(string_to_sign, SECRET_KEY_PREFIX + secret_key)
    http_request.path = "{0}{1}{2}{3}{4}".format(servlet_path, QUERY_START_SYMBOL, canonical_query_string,
                                                 PARAMETER_SEPARATOR,
                                                 QUERY_STRING_PATTERN.format(SIGNATURE, percent_encode(signature)))


def get_date(fmt):
    return datetime.datetime.now().strftime(fmt)


def nonce():
    return str(uuid.uuid4()).replace("-", "")


def sha256_encode_hex_string(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def hmac_sha1_hex_string(text, secret_key):
    return hmac.new(secret_key.encode('utf-8'), text.encode('utf-8'), hashlib.sha1).hexdigest()
