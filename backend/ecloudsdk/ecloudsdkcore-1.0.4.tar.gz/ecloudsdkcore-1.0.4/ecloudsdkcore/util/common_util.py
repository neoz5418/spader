# coding: utf-8


def default_value(real_val, default_val):
    if real_val is not None:
        return real_val
    return default_val


def is_unset(value):
    if value is None:
        return True
    if isinstance(value, str):
        return len(value) == 0
    return value is None


def is_set(value):
    return not is_unset(value)


DEFAULT_ENDPOINT = "https://ecloud.10086.cn"
