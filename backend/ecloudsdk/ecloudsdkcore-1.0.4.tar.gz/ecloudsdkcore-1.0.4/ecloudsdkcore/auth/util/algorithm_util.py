import base64
import hashlib
import hmac

from Crypto.Hash import MD5
from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15


def hmac_sha1_hex_string(text, secret_key):
    return hmac.new(secret_key.encode('utf-8'), text.encode('utf-8'), hashlib.sha1).hexdigest()


def hmac_sha1_hex_string(text, secret_key):
    return hmac.new(secret_key.encode('utf-8'), text.encode('utf-8'), hashlib.sha1).hexdigest()


def base64_decode_str(base64_str):
    return base64.b64decode(base64_str).decode('utf-8')


def base64_decode(base64_str):
    return base64.b64decode(base64_str)


def base64_encode_str(bytes_data):
    return base64.b64encode(bytes_data).decode('utf-8')


def base64_encode(bytes_data):
    return base64.b64encode(bytes_data)


def generate_rsa_signature(private_key_base64, data_to_sign):
    key_bytes = base64.b64decode(private_key_base64)
    rsa_key = RSA.import_key(key_bytes)
    hashed = MD5.new(data_to_sign.encode('utf-8'))
    signature = pkcs1_15.new(rsa_key).sign(hashed)
    return base64.b64encode(signature).decode('utf-8')


def sha256_encode_hex_string(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()
