import time

from ecloudsdkcore.exception.exceptions import RetryException, SdkException
from ecloudsdkcore.retry.context import ErrorContext, ResultContext, Context


class RetryTemplate(object):
    def __init__(self, retry_policy, retry_times, max_during_time):
        self.retry_policy = retry_policy
        self.retry_times = retry_times
        self.max_during_time = max_during_time

    def call(self, retry_func, http_request, return_type, runtime_config):
        start_time = time.time() * 1000
        retry_times = 1
        while True:
            try:
                res = retry_func(http_request, return_type, runtime_config)
                duration = time.time() * 1000 - start_time
                ctx = ResultContext(result=res, retry_times=retry_times, delay_time=duration)
            except SdkException as info:
                duration = time.time() * 1000 - start_time
                ctx = ErrorContext(error=info, retry_times=retry_times, delay_time=duration)
            if isinstance(ctx, ResultContext):
                return ctx.result
            if retry_times == self.retry_times:
                raise RetryException(num_failed_attempts=retry_times,
                                     max_during_time_failed_attempts=None,
                                     last_failed_retry_context=ctx)
            elif duration >= self.max_during_time:
                raise RetryException(num_failed_attempts=retry_times,
                                     max_during_time_failed_attempts=duration,
                                     last_failed_retry_context=ctx)
            else:
                sleep_time = self.retry_policy.compute_wait_time(ctx)
                if sleep_time > 0:
                    time.sleep(sleep_time / 1000)
            retry_times += 1
