# coding: utf-8


class SdkException(Exception):
    """
    The base exception class of sdk.
    """

    def __init__(self, error_type, error_message, reason=None):
        self.error_type = error_type
        self.error_message = error_message
        self.reason = reason

    def __str__(self):
        error_info = "%s - %s\n" % (self.error_type, self.error_message)
        if self.reason:
            error_info += "reason: %r\n" % self.reason
        return error_info


class SignatureException(SdkException):
    def __init__(self, error_message, reason=None):
        super(SignatureException, self).__init__("SignatureException", error_message, reason)


class SslHandShakeException(SdkException):
    def __init__(self, error_message, reason=None):
        super(SslHandShakeException, self).__init__("SslHandShakeException", error_message, reason)


class ServerRequestException(SdkException):
    def __init__(self, error_message, reason=None):
        super(ServerRequestException, self).__init__("ServerRequestException", error_message, reason)


class ConnectTimeoutException(SdkException):
    def __init__(self, error_message, reason=None):
        super(ConnectTimeoutException, self).__init__("ConnectTimeoutException", error_message, reason)


class ServerResponseException(SdkException):

    def __init__(self, error_message, code, body=None, headers=None, reason=None):
        super(ServerResponseException, self).__init__("ServerResponseException", error_message, None)
        self.error_message = error_message
        self.code = code
        self.body = body
        self.headers = headers
        self.reason = reason

    def __str__(self):
        error_info = super(ServerResponseException, self).__str__()
        if self.code:
            error_info += "Http response code: %d\n" % self.code
        if self.headers:
            error_info += "HTTP response headers: %s\n" % self.headers
        if self.body:
            error_info += "HTTP response body: %s\n" % self.body

        return error_info


class RetryException(SdkException):

    def __init__(self, num_failed_attempts=None, max_during_time_failed_attempts=None, last_failed_retry_context=None):
        super(RetryException, self).__init__("RetryException", "Excute Retry Call Error", None)
        self.num_failed_attempts = num_failed_attempts
        self.max_during_time_failed_attempts = max_during_time_failed_attempts
        self.last_failed_retry_context = last_failed_retry_context

    def __str__(self):
        error_info = super(RetryException, self).__str__()
        if self.num_failed_attempts is not None and self.num_failed_attempts > 0:
            error_info += "Retrying failed to complete successfully after %d attempts.\n" % \
                          self.num_failed_attempts
        if self.max_during_time_failed_attempts is not None and self.max_during_time_failed_attempts > 0:
            error_info += "Retrying failed to complete successfully after %s milliseconds\n" % \
                          self.max_during_time_failed_attempts
        return error_info


class InvalidParameterException(SdkException):
    def __init__(self, error_message, reason=None):
        super(InvalidParameterException, self).__init__("InvalidParameterException", error_message, reason)

class CredentialException(SdkException):
    def __init__(self, error_message, reason=None):
        super(CredentialException, self).__init__("CredentialException", error_message, reason)

