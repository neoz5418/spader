import abc


class Context(abc.ABC):
    @abc.abstractmethod
    def get(self):
        pass

    @abc.abstractmethod
    def has_result(self):
        pass

    @abc.abstractmethod
    def has_error(self):
        pass

    @abc.abstractmethod
    def get_result(self):
        pass

    @abc.abstractmethod
    def get_retry_times(self):
        pass

    @abc.abstractmethod
    def get_delay_time(self):
        pass


class ResultContext(Context):
    def __init__(self, result, retry_times, delay_time):
        self.result = result
        self.retry_times = retry_times
        self.delay_time = delay_time

    def get(self):
        return self.result

    def has_result(self):
        return True

    def has_error(self):
        return False

    def get_result(self):
        return self.result

    def get_retry_times(self):
        return self.retry_times

    def get_delay_time(self):
        return self.delay_time


class ErrorContext(Context):
    def __init__(self, error, retry_times, delay_time):
        self.error = error
        self.retry_times = retry_times
        self.delay_time = delay_time

    def get(self):
        return self.error

    def has_result(self):
        return False

    def has_error(self):
        return True

    def get_result(self):
        return self.error

    def get_retry_times(self):
        return self.retry_times

    def get_delay_time(self):
        return self.delay_time
