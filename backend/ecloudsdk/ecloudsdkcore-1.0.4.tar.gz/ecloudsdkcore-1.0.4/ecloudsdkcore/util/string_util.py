# coding: utf-8
from urllib.parse import quote_plus

from ecloudsdkcore.util.common_util import is_set


def percent_encode(url_str):
    return quote_plus(url_str) \
        .replace('+', '%20') \
        .replace('*', '%2A') \
        .replace('%7E', '~')


def has_text(s):
    return is_set(s) and len(s) > 0


def is_empty(s):
    return not has_text(s)
